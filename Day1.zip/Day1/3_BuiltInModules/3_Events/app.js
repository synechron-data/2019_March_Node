const StringEmitter = require('./StringEmitter');

let obj = new StringEmitter();

obj.on('data', function (s) {
    // console.log("S1 - ", s);
    // Send to Client (WebSocket)
});

var count = 0;
function S2(s) {
    ++count;
    console.log("S2 - ", s.toUpperCase());
    if (count > 2) {
        obj.removeListener('data', S2);
    }
}

obj.on('data', S2);

// obj.getStringWithCallback(function(s){
//     console.log(s);
// });

// setInterval(function () {
//     var s = obj.getString();
//     console.log(s);
// }, 2000);