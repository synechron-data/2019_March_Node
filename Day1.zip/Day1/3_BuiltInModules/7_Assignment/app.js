const fs = require('fs');

module.exports.HttpHandler = function (req, res) {
    
}