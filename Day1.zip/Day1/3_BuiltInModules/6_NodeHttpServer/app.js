// module.exports.HttpHandler = function (req, res) {
//     console.log(req.url);
//     res.write("<h1>Response from Node Http Server</h1>");
//     res.end();
// }

const fs = require('fs');

module.exports.HttpHandler = function (req, res) {
    fs.readFile('./index.html', 'utf-8', (err, data) => {
        if (err) throw err;

        res.writeHeader(200, { "content-type": "text/html" });
        res.write(data);
        res.end();
    });
}