const http = require('http');
const app = require('./app');

var server = http.createServer(app.HttpHandler);

server.listen(3000, function () {
    console.log("Server Started...");
});