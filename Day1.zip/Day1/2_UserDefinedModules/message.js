var fname = "Manish";
var lname = "Sharma";

// module.exports = fname;
// module.exports = lname;

module.exports.firstname = fname;
module.exports.lastname = lname;

module.exports.log = function (m) {
    console.log(m + ', logged using message.js')
}

class Person {
    constructor(name) {
        this._name = name;
    }
    
    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}

module.exports.Person = Person;