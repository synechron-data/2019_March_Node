module.exports.log = function (m) {
    console.log(m + ', logged using logger1 index.js')
}