// var msg = require('./message.js');
// console.log(msg);
// console.log(msg.firstname);
// console.log(msg.lastname);

// var msg = require('./message.js');
// msg.log("Hi");

// var msg = require('./message.js');
// var p1 = new msg.Person("Manish");
// console.log(p1.getName());
// p1.setName("Abhijeet");
// console.log(p1.getName());

// var msg = require('./message');
// console.log(msg);

// var logger = require('./logger1/loggerOne');
var logger = require('./logger1');
logger.log("Hi");

