const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const logger = require('morgan');

const app = express();

const employees = [{ id: 1, name: "Manish" },
{ id: 2, name: "Abhijeet" },
{ id: 3, name: "Ram" },
{ id: 4, name: "Abhishek" },
{ id: 5, name: "Ramakant" }];

app.set('view engine', 'pug');

app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));

// app.use(function (req, res, next) {
//     var stTime = (new Date()).getTime();
//     next();
//     var enTime = (new Date()).getTime();

//     var tTime = enTime - stTime;
//     console.log("Total Response Time: ", tTime, "ms");
// });

app.use(function (req, res, next) {
    console.log("Request - Middleware 1");
    req.test = "My Test";
    next();
    console.log("Response - Middleware 1");
});

app.use(function (req, res, next) {
    console.log("Request - Middleware 2");
    console.log(req.test);
    next();
    console.log("Response - Middleware 2");
});

app.get('/', (req, res) => {
    // console.log("Request - Get Handler");
    res.render('index', { ptitle: "Default" });
});

app.get('/employees', (req, res) => {
    res.render('employees', { ptitle: "Employees View", empList: employees });
});

app.listen(3000, () => {
    console.log("Express Server Started...");
});