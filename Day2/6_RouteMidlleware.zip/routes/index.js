const express = require('express');
const router = express.Router();

const homeController = require('../controllers/homeController');
const employeesController = require('../controllers/employeesController');

router.get('/', homeController.index);

router.get('/employees', employeesController.index);

module.exports = router;