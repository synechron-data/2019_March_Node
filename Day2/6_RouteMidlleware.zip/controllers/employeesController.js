const da = require('../dataaccess');

module.exports.index = (req, res) => {
    res.render('employees/index', { ptitle: "Employees View", empList: da.getAllEmployees() });
}