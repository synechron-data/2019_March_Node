module.exports.index = function (req, res) {
    res.render('home/index', { ptitle: "Default" });
}