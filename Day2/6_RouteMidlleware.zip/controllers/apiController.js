const da = require('../dataaccess');

module.exports.getEmployees = (req, res) => {
    res.json(da.getAllEmployees());
}